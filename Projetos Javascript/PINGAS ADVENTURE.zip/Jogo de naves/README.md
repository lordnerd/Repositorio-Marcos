# Jogo de Naves emoji:rocket:

Jogo de naves produzido para o Bootcamp da Órbi Web Games Developer em parceria com a Digital Innovation One.



## Descrição do projeto

Foi desenvolvido um jogo de naves utilizando HTML5, CSS3, jQuery e Javascript.

### Como usar

Para executarmos o projeto, basta apenas abrir o arquivo index.html em um navegador de preferência. Use as teclas W e S para se mover para cima e para baixo e D pra atirar.

